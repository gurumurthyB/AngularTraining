"use strict";
exports.__esModule = true;
var Student_1 = require("./Student");
var students = [
    new Student_1.Student("A", 1),
    new Student_1.Student("B", 2),
    new Student_1.Student("C", 3)
];
exports["default"] = students;
