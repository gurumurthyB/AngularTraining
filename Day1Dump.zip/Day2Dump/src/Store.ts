import {Student} from './Student'

export default  students: Student[] = [
    new Student("A", 1),
    new Student("B", 2),
    new Student("C", 3)

];

