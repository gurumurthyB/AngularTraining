import students from './Store'
import { Student } from './Student'

students.forEach(s =>{
    console.log(s.getName(),s["subject"](), s.getAge())
});