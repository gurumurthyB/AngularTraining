import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/common/Customer';
import { DataService } from 'src/common/data.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
customers:Customer[] =[];
textSearch:String ="";
mainCustomers: Customer[] = [];
mode:string = "card"
  constructor(private dataService:DataService) { }
  removeCustomer(id:number){
    console.log("customer parent" ,id)
    
    this.dataService.deleteCustomer(id).subscribe(data =>{
      console.log("deleted!!!")
      this.refreshPage();
      
    });
  }

  filterCustomers(){
    this.customers =  this.mainCustomers.filter(c =>
       {return (c.firstName.toUpperCase().indexOf(this.textSearch.toUpperCase()) >= 0) ||
        (c.lastName.toUpperCase().indexOf(this.textSearch.toUpperCase()) >= 0)
    });
  }
  loadView(){
    if(this.mode =="list")
    this.mode= "card";
    if(this.mode=="card")
    this.mode ="list";
  }
  refreshPage(){
    this.dataService.getCustomers().subscribe(data=>{
      this.customers = this.mainCustomers = data;
      this.textSearch="";
    })
  }
  ngOnInit(): void {
    // this.mainCustomers = this.customers = [
    //   {
    //     "id": 1,
    //     "firstName": "Rachel",
    //     "lastName": "Green ",
    //     "gender": "female",
    //     "address": "Singapore"
    //   },
    //   {
    //     "id": 2,
    //     "firstName": "Chandler",
    //     "lastName": "Song",
    //     "gender": "male",
    //     "address": "Bugis"
    //   },
    //   {
    //     "id": 4,
    //     "firstName": "Monica",
    //     "lastName": "Gellers",
    //     "gender": "female",
    //     "address": "Victoria Street"
    //   },
    //   {
    //     "id": 5,
    //     "firstName": "Ross",
    //     "lastName": "Geller",
    //     "gender": "male",
    //     "address": "M G Road"
    //   },
    //   {
    //     "id": 6,
    //     "firstName": "Phoebe",
    //     "lastName": "Buffay",
    //     "gender": "female",
    //     "address": "Df"
    //   }
    // ]

    this.refreshPage();
  }

  

}
