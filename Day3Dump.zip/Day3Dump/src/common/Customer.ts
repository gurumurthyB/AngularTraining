export interface Customer{
    id:number;
    firstName:String;
    lastName:string;
    address:string;
    gender:string
}